#!/bin/bash
#
# mdsant.sh
#

function usage {
	echo "USAGE: mdsant.sh [ENVIRONMENT] {[TARGET]} {[FOLDER_NAME]}"
	echo "       Leaving [TARGET] will execute the default target (all)"
	exit 1
}

if [ -z $1 ]
then
	usage
fi

if [ -f uwvant_environment_settings.sh ]
then
	. ./uwvant_environment_settings.sh
elif [ -f ../uwvant_environment_settings.sh ]
then
	. ../uwvant_environment_settings.sh
else
	. ../../uwvant_environment_settings.sh
fi

export ANT_HOME=$SCA_ANT_HOME
export JAVA_HOME=$SCA_JAVA_HOME

export ANT_BASE_DIR=$SCA_ORACLE_HOME/jdeveloper/bin
export ANT_BUILD_FILE=$DEPLOYMENT_HOME/BUILD-FILES/MDS-build.xml

if [ "$SCA_OS" = "Cygwin" ]
then
	export ANT_HOME=`cygpath -w "$ANT_HOME"`
	export DEPLOYMENT_HOME=`cygpath -w "$DEPLOYMENT_HOME"`
	export JAVA_HOME=`cygpath -w "$JAVA_HOME"`
	#export SCA_ANT_HOME=`cygpath -w "$SCA_ANT_HOME"`
	export SCA_JAVA_HOME=`cygpath -w "$SCA_JAVA_HOME"`
	export SCA_ORACLE_HOME=`cygpath -w "$SCA_ORACLE_HOME"`
	
	export ANT_BASE_DIR=`cygpath -w "$ANT_BASE_DIR"`
	export ANT_BUILD_FILE=`cygpath -w "$ANT_BUILD_FILE"`
	
	echo "Using Cygwin paths:"
	echo "- ANT_HOME: $ANT_HOME"
	echo "- DEPLOYMENT_HOME: $DEPLOYMENT_HOME"
	echo "- JAVA_HOME: $JAVA_HOME"
	echo "- SCA_ANT_HOME: $SCA_ANT_HOME"
	echo "- SCA_JAVA_HOME: $SCA_JAVA_HOME"
	echo "- SCA_ORACLE_HOME: $SCA_ORACLE_HOME"
	echo "- ANT_BASE_DIR: $ANT_BASE_DIR"
	echo "- ANT_BUILD_FILE: $ANT_BUILD_FILE"
fi

export COMMAND="$SCA_ANT_HOME/bin/ant -f $ANT_BUILD_FILE -Dbasedir=$ANT_BASE_DIR -Dotap=$1 $2"
if [ $3 ]
then
	export COMMAND="$COMMAND -DfolderName=$3"
fi

$COMMAND
