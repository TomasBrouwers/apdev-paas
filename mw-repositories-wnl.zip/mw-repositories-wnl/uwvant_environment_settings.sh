#!/bin/bash
#
# uwvant_environment_settings.sh
#

export DEPLOYMENT_HOME=$SOADeploymentHome/deployment

export JAVA_HOME=$DEPLOYMENT_HOME/CLASSES/jdk
export SOA_HOME=$DEPLOYMENT_HOME/CLASSES/OracleSOA

export SCA_ORACLE_HOME=$SOAOracleHome
export SCA_ANT_HOME=$SCA_ORACLE_HOME/jdeveloper/ant
export SCA_JAVA_HOME=$SOAJavaHome
export SCA_OS=`uname -o`
